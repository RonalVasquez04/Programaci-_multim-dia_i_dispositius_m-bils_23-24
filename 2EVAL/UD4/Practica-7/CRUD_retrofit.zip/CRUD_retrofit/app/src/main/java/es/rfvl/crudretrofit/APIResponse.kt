package es.rfvl.crudretrofit

import com.google.gson.annotations.SerializedName

data class APIResponse(
    @SerializedName("id") val id: String,
    @SerializedName("brand") val brand: String,
    @SerializedName("model") val model: String,
    @SerializedName("photo") var photo: String
)

