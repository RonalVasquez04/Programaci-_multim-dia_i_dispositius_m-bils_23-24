package es.rfvl.crudretrofit

import android.app.AlertDialog
import android.app.Dialog
import android.content.Context
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.Toast
import androidx.fragment.app.DialogFragment


class DeleteDialogFragment : DialogFragment() {
    private lateinit var mListener: DeleteDialogDelete
    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {
        return activity?.let {
            val builder = AlertDialog.Builder(it)
            val inflater = requireActivity().layoutInflater
            val view = inflater.inflate(R.layout.fragment_delete_dialog, null)
            val btnDelete: Button = view.findViewById(R.id.btnDelete)
            val btnCancel: Button = view.findViewById(R.id.btnCancelDelete)

            btnDelete.setOnClickListener{
                mListener.onDialogDeleteClick()
                dialog?.dismiss()
            }
            btnCancel.setOnClickListener{
                Toast.makeText(requireContext(),"CANCEL", Toast.LENGTH_SHORT).show()
                dialog?.dismiss()
            }
            builder
                .setView(view)
            builder.create()
        } ?: throw IllegalStateException("Activity cannot be null")
    }

    interface DeleteDialogDelete {
        fun onDialogDeleteClick()
    }

    override fun onAttach(context: Context) {
        super.onAttach(context)

        if (context is DeleteDialogDelete){
            mListener = context
        }
        else{
            throw Exception("Your Fragment or activity must implement the interface FirstDialogListener")
        }
    }



}