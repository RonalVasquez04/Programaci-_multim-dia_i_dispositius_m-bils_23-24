package es.rfvl.crudretrofit

import es.rfvl.crudretrofit.classes.Car
import retrofit2.Call
import retrofit2.Response
import retrofit2.http.Body
import retrofit2.http.DELETE
import retrofit2.http.GET
import retrofit2.http.POST
import retrofit2.http.PUT
import retrofit2.http.Path

interface CarsService {


    @GET("cars")
    suspend fun getCars(): Response<List<APIResponse>>

    @PUT("cars/{id}")
    suspend fun updateCar(@Path("id") id: String, @Body car: Car): Response<Car>

    @POST("cars")
    suspend fun createCar(@Body car: Car): Response<Car>

    @DELETE("cars/{id}")
    suspend fun deleteItem(@Path("id") id: String): Response<Car>


}

