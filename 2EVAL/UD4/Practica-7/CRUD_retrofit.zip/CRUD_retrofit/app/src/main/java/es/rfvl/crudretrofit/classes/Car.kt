package es.rfvl.crudretrofit.classes

data class Car (val id: String, val brand: String, val model: String, val photo: String)
