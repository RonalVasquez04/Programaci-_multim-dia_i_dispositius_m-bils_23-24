package es.rfvl.crudretrofit

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.widget.Toast
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.GridLayoutManager
import es.rfvl.crudretrofit.adapters.carsAdapter
import es.rfvl.crudretrofit.classes.Car
import es.rfvl.crudretrofit.databinding.ActivityMainBinding
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext


class MainActivity : AppCompatActivity(), AddDialogFragment.AddDialogAdd, DeleteDialogFragment.DeleteDialogDelete, UpdateDialogFragment.UpdateDialog   {
    private  lateinit var mAdapter: carsAdapter
    private lateinit var binding: ActivityMainBinding
    private lateinit var listCars: MutableList<APIResponse>
    private lateinit var carService: CarsService


    private var carElegido: String = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityMainBinding.inflate(layoutInflater)

        setUpReciclerView()
        carService = RetrofitObject.getInstance()
            .create(CarsService::class.java)
        setSupportActionBar(binding.myToolbar)
        fetchDataAndUpdateUI()

        setContentView(binding.root)

    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.main_menu, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem) = when(item.itemId){
        R.id.action_add ->{

            val dialogFragment = AddDialogFragment()
            dialogFragment.show(supportFragmentManager, "")
            true
        }

        else ->  false
    }

    private fun setUpReciclerView() {
        listCars = emptyList<APIResponse>().toMutableList()
        mAdapter = carsAdapter(listCars,{ car->
            carElegido = car.id
            UpdateDialogFragment(car).show(supportFragmentManager, "")
        }) { car ->
            carElegido = car.id
            DeleteDialogFragment().show(supportFragmentManager, "")
        }
        binding.myRecView.layoutManager = GridLayoutManager(this,1)
        binding.myRecView.adapter = mAdapter
    }



    private fun fetchDataAndUpdateUI() {
        lifecycleScope.launch(Dispatchers.IO){
            val response = carService.getCars()
            withContext(Dispatchers.Main){
                if (response.isSuccessful){
                    val carsList = response.body() ?: emptyList()
                    mAdapter = carsAdapter(carsList,{ car->
                        carElegido = car.id
                        UpdateDialogFragment(car).show(supportFragmentManager, "")
                    }) { car ->
                        carElegido = car.id
                        DeleteDialogFragment().show(supportFragmentManager, "")
                    }
                    binding.myRecView.adapter = mAdapter
                }
                else{
                    Toast.makeText(this@MainActivity, "Error en la API", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    override fun onClickDialogAdd(brand: String, model: String, image: String) {
        lifecycleScope.launch(Dispatchers.IO) {
                withContext(Dispatchers.Main) {
                    if (carService.createCar(Car("", brand, model, image)).isSuccessful) {
                        fetchDataAndUpdateUI()
                    }
                }

        }
    }


    override fun onDialogDeleteClick() {
        lifecycleScope.launch(Dispatchers.IO) {

                withContext(Dispatchers.Main) {
                    if (carService.deleteItem(carElegido).isSuccessful) {
                        Toast.makeText(this@MainActivity, "Carro eliminado", Toast.LENGTH_SHORT).show()
                        fetchDataAndUpdateUI()
                    }
                }

        }
    }

    override fun onClickDialogUpdate(brand: String, model: String, image: String) {

        lifecycleScope.launch(Dispatchers.IO) {
                withContext(Dispatchers.Main) {
                    if (carService.updateCar(carElegido, Car(carElegido, brand, model, image)).isSuccessful) {
                        fetchDataAndUpdateUI()
                    }
                }

        }
    }


}