package es.rfvl.crudretrofit

import android.app.AlertDialog
import android.app.Dialog
import android.content.Context
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.fragment.app.DialogFragment

class UpdateDialogFragment(private val car: APIResponse) : DialogFragment() {

    private lateinit var mListener: UpdateDialog

    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {
        return activity?.let {
            val builder = AlertDialog.Builder(it)
            val inflater = requireActivity().layoutInflater
            val view = inflater.inflate(R.layout.fragment_update_dialog, null)
            var photo: EditText = view.findViewById(R.id.textoIntroducidoURLUpdate)
            var brand: EditText = view.findViewById(R.id.textoIntroducidoBrandUpdate)
            var model: EditText = view.findViewById(R.id.textoIntroducidoModelUpdate)
            val btnAdd: Button = view.findViewById(R.id.btnUpdate)
            val btnCancel: Button = view.findViewById(R.id.btnCancelUpdate)

            photo.setText(car.photo)
            brand.setText(car.brand)
            model.setText(car.model)

            btnAdd.setOnClickListener{
                val brandText = brand.text.toString()
                val modelText = model.text.toString()
                val imageText = photo.text.toString()
                mListener.onClickDialogUpdate(brandText, modelText, imageText)
                dialog?.dismiss()
            }
            btnCancel.setOnClickListener{
                Toast.makeText(requireContext(),"CANCEL", Toast.LENGTH_SHORT).show()
                dialog?.dismiss()
            }


            builder
                .setView(view)
            builder.create()
        } ?: throw IllegalStateException("Activity cannot be null")
    }

    interface UpdateDialog{
        fun onClickDialogUpdate(brand: String, model: String, image: String)
    }
    override fun onAttach(context: Context) {
        super.onAttach(context)

        if (context is UpdateDialog){
            mListener = context
        }
        else{
            throw Exception("Your Fragment or activity must implement the interface FirstDialogListener")
        }
    }



}