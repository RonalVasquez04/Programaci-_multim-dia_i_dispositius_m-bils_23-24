package es.rfvl.crudretrofit

import android.app.AlertDialog
import android.app.Dialog
import android.content.Context
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.fragment.app.DialogFragment


class AddDialogFragment : DialogFragment() {

    private lateinit var mListener: AddDialogAdd

    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {
        return activity?.let {
            val builder = AlertDialog.Builder(it)
            val inflater = requireActivity().layoutInflater
            val view = inflater.inflate(R.layout.fragment_add_dialog, null)
            var photo: EditText = view.findViewById(R.id.textoIntroducidoURL)
            var brand: EditText = view.findViewById(R.id.textoIntroducidoBrand)
            var model: EditText = view.findViewById(R.id.textoIntroducidoModel)
            val btnAdd: Button = view.findViewById(R.id.btnAdd)
            val btnCancel: Button = view.findViewById(R.id.btnCancel)

            btnAdd.setOnClickListener{
                val brandText = brand.text.toString()
                val modelText = model.text.toString()
                val imageText = photo.text.toString()
                mListener.onClickDialogAdd(brandText, modelText, imageText)
                dialog?.dismiss()
            }
            btnCancel.setOnClickListener{
                Toast.makeText(requireContext(),"CANCEL",Toast.LENGTH_SHORT).show()
                dialog?.dismiss()
            }


            builder
                .setView(view)
            builder.create()
        } ?: throw IllegalStateException("Activity cannot be null")
    }

    interface AddDialogAdd{
        fun onClickDialogAdd(brand: String, model: String, image: String)
    }
    override fun onAttach(context: Context) {
        super.onAttach(context)

        if (context is AddDialogAdd){
            mListener = context
        }
        else{
            throw Exception("Your Fragment or activity must implement the interface FirstDialogListener")
        }
    }
}