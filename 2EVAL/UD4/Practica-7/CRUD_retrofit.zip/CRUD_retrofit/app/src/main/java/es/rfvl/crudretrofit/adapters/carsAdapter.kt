package es.rfvl.crudretrofit.adapters

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.squareup.picasso.Picasso
import es.rfvl.crudretrofit.APIResponse
import es.rfvl.crudretrofit.R
import es.rfvl.crudretrofit.classes.Car

class carsAdapter (private val cars: List<APIResponse>, private val mListener: (APIResponse) -> Unit, private val mLongClickListener: (APIResponse) -> Unit): RecyclerView.Adapter<carsAdapter.CarsViewFolder>(){
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CarsViewFolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.rec_view, parent, false)
        return CarsViewFolder(view)
    }

    override fun onBindViewHolder(holder: CarsViewFolder, position: Int) {
        val car = cars[position]
        holder.bindItem(car)
        holder.itemView.setOnClickListener{mListener(car)}
        holder.itemView.setOnLongClickListener{ mLongClickListener(car)
            true
        }
    }

    override fun getItemCount(): Int {
        return cars.size
    }


    class CarsViewFolder(view: View): RecyclerView.ViewHolder(view){
        private val photo: ImageView = view.findViewById(R.id.imagenRec)
        private val brand: TextView = view.findViewById(R.id.textBrand)
        private val model: TextView = view.findViewById(R.id.textModel)

        fun bindItem(i:APIResponse){
            if (!i.photo.isNullOrBlank()) {
                Picasso.get().load(i.photo).into(photo)
            }

            brand.text = i.brand
            model.text = i.model
        }

    }

}